'use strict';
(function(){
let card;
document.addEventListener('DOMContentLoaded',init);
function init(){
    card=document.getElementById('card');
    document.getElementById('pick').addEventListener('click',update);
}
let i=0;
function update(){
/* card.textContent=(i++); */
const suite=Math.floor(Math.random()*4);//number 0,1,2,or 3
const rank=Math.ceil(Math.random()*13)// 1 to 13
let symbol;
if(suite===0){
    symbol='\u2660';
    card.classList.remove('red');
} else if(suite===1){
    symbol='\u2663';
    card.classList.remove('red');
} else if(suite===2){
    symbol='\u2665';
    card.classList.add('red');
}  else {
    symbol='\u2666';
    card.classList.add('red');
}
card.textContent=`${symbol} ${rank}`;
}
})();