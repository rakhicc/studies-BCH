'use strict';

const {
    getBooksOfPerson,
    getTheNamesOfBooks,
    gettotalprice,
    getownerOfBooks,
    getAllbooksthatIncludes
} = require('./bookstorage.js');

/* console.log(getTheNamesOfBooks('Leila','Hökki'));
console.log(getTheNamesOfBooks('Vera','River'));
console.log(getBooksOfPerson('Matt', 'River'));
console.log(getBooksOfPerson('Leila', 'Hökki'));
console.log(getBooksOfPerson('X', 'Hökki'));
console.log(getBooksOfPerson('Vera', 'River'));
console.log("totalPriceof books"+gettotalprice('X', 'Hökki'));
console.log(getownerOfBooks("ABC"));
console.log(getownerOfBooks("x")); */
console.log("getAllbooksthatIncludes");
console.log(getAllbooksthatIncludes("ABC"));