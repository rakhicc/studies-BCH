'use strict';

const [,,numberA,op,numberB]=process.argv;

let result=0;
const first = +numberA;
const second = +numberB;

if(op==='+'){
    result=first+second;
}
else if(op==='-'){
    result=first-second;
}
else if(op==='x'){
    result=first*second;
}
else if(op==='/'){
    result=first/second;
}
console.log(result);
console.log(`${first} ${op} ${second} = ${result}`);
console.log(first+' '+op+' '+second+' = '+result);