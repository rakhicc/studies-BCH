import React from "react";
import styles from "./SettingsPage.module.css";
import Header from "../Header";

const SettingsPage = () => {
  return (
    <div>
      <Header />
    </div>
  );
};

export default SettingsPage;
