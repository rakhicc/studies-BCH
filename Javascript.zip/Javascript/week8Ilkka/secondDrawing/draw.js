'use strict';
(function(){
let drawingArea;
document.addEventListener('DOMContentLoaded',init);
function init(){
    drawingArea=document.getElementById("drawingArea");
    const drawingContext=drawingArea.getContext('2d');
    drawingContext.fillStyle='red';
    drawBox(drawingContext,200,200,100,100,'green');
    drawingContext.fillRect(10,10,100,40);
    drawBox(drawingContext,20,150,100,70,'orange',true);
const heights=[10,30,40,20];
let x=10;
for(let value of heights){
drawBox(drawingContext,x,70,10,value,'blue');
x+=20;
}
x=300;
for(let value of heights){
    drawBox(drawingContext,x,70-value,10,value,'violet');
    x+=20; 
}
let y=250;
for(let value of heights){
    drawBox(drawingContext,20,y,value,10,'cyan');
    y+=20; 
}
const anotherCanvas =document.getElementById("anotherCanvas");
const anotherContext=anotherCanvas.getContext('2d');
drawBox(anotherContext,100,100,200,100,'orange',true);
drawBox(anotherContext,150,120,50,70,'green');
}
function drawBox(context,x,y,width,height,color,drawBorder=false){
context.save();
    context.fillStyle=color;
context.fillRect(x,y,width,height);
if(drawBorder){
    context.strokeStyle='black';
    context.lineWidth=3;
    context.strokeRect(x,y,width,height);
}
context.restore();
}
})();