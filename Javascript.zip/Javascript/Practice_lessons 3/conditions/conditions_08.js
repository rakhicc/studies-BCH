function getDescription(text) {
    if (text.length > 10) {
        return `${text.substring(0,10)}...`;
    }
    return text;
}

console.log(getDescription('javascriptbasics'));
console.log(getDescription('java'));