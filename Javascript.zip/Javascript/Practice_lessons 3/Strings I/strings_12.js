'use strict';
/*
Complete the function getMultilineString such that it returns the following multiline string:

I am learning JavaScript
and I found it to be
quite fun!
The tests are case-sensitive. So, it's a good idea to copy-paste the string instead of re-writing it.

Test:
returns a string
returns expected multi-line string

*/

function getMultilineString() {
    return `I am learning JavaScript
and I found it to be
quite fun!`;
}

// Sample usage - do not modify
console.log(getMultilineString());
