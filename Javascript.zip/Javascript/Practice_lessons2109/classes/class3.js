'use strict';

/**
Write the Recipe class such that it automatically console logs the string: New recipe created whenever
we create a new instance of that class.
**/

// write class definition

class Recipe{
constructor(){
    console.log("New recipe created");
}
}

// Class usage
let pasta = new Recipe();
let cutlet = new Recipe();