const array=[1,2,3,4];
const poped=array.pop();
console.log(poped);
console.log(array);

const array1=array.unshift(5,6);
console.log(array1);
console.log(array);


const animals = ['ant', 'bison', 'camel', 'duck', 'elephant'];

console.log(animals.slice(2));
// expected output: Array ["camel", "duck", "elephant"]

console.log(animals.slice(2, 4));
// expected output: Array ["camel", "duck"]

console.log(animals.slice(1, 5));
// expected output: Array ["bison", "camel", "duck", "elephant"]

console.log(animals.slice(-2));
// expected output: Array ["duck", "elephant"]

console.log(animals.slice(2, -2));
// expected output: Array ["camel", "duck"]