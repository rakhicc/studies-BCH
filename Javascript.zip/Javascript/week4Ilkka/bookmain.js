'use strict';
const {getbooksofaperson,getnamesofbooks}=require('./bookstorage');
console.log(getnamesofbooks('reshu','chandran'));