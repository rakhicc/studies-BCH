package org.helloworld;

import org.springframework.web.bind.annotation.RequestMapping;

public class HelloController {
	@RequestMapping("/")
    String hello() {
        return "Hello World, Spring Boot!";
    }

}
