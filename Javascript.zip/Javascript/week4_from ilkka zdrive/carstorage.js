'use strict';

const cars = require('./cars.json');

function getWithLicence(licence){
    for(let car of cars){
        if(car.licence===licence){
            return car;
        }
    }
    return null;
}

// function getWithModel(model){
//     const found=[];
//     for(let car of cars){
//         if(car.model===model){
//             found.push(car);
//         }
//     }
//     return found;
// }

function getWithModel(model){
    return cars.filter(car=>car.model===model);
}

function getAllModels(){
    const models=[];
    for(let car of cars){
        if(!models.includes(car.model)){
            models.push(car.model);
        }
    }
    return models;
}

// function getCar(key, value){
//     const found=[];
//     for(let car of cars){
//         if(car[key]===value){
//             found.push(car);
//         }
//     }
//     return found;
// }

const getCar = (key, value)=> {
    const found = [];
    for (let car of cars) {
        if (car[key] === value) {
            found.push(car);
        }
    }
    return found;
}

module.exports={
    getWithLicence, 
    getWithModel, 
    getAllModels,
    getCar
};