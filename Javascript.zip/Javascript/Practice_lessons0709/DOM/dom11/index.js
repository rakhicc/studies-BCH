const getShortTextParagraphs = () => {
const nodelistofparagraphs= document.querySelectorAll("p");
const array=[...nodelistofparagraphs].filter(nodelistofparagraph=> nodelistofparagraph.textContent.length<10);
return array;

}

// Sample usage - do not modify
console.log(getShortTextParagraphs());
