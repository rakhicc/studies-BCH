'use strict';



(function(){
 
 let inputfield;

 let idField;
let nameField;
let typeField;
let processorField;
let amountField;

 document.addEventListener('DOMContentLoaded',init);
 function init(){
     
     inputfield=document.getElementById('id');
     document.getElementById('submit').addEventListener('click',send);
     document.getElementById('buttonUpdate').addEventListener('click',update);
 }

 async function update(){
    clearMessagearea();
    idField=document.getElementById('computerid');
    nameField=document.getElementById('name');
    typeField=document.getElementById('type');
    processorField=document.getElementById('processor');
    amountField=document.getElementById('amount');
    const computer={
        id:idField.value,
        name:nameField.value,
        type:typeField.value,
        processor:processorField.value,
        amount:amountField.value
    }

    try{
const options={
    method:'POST',
    body:JSON.stringify(computer),
    headers:{'Content-type':'application/json'
}
};
const data=await fetch('/update',options);
const resultJson=await data.json();
if(resultJson.message){
    updateMessagearea(resultJson.message,resultJson.type);
}
    }catch(error){
        updateMessagearea(error.clearMessagearea,'error');
    }
}
async function send(){
    clearMessagearea();
   
    const id=inputfield.value;
    console.log(id);
    try{
const options={
    method:'POST',
    body:JSON.stringify({id}),
    headers:{
        'Content-Type':'application/json'
    }

};
const data=await fetch('/getOne',options);
const resultJson=await data.json();
updatePage(resultJson);
    }catch(error){
    updateMessagearea(error.message,'error');
}
}
function updatePage(result){
    if(result){
        if(result.message){
            updateMessagearea(result.message,result.type);
        } else {
            updateComputer(result);
        }
    }
}
function updateComputer(computer){
    console.log('computer.id',computer.id);
    document.getElementById('update').style.display="grid";
    
    document.getElementById('name').value=computer.name;
    document.getElementById('type').value=computer.type;
    document.getElementById('processor').value=computer.processor;
    document.getElementById('amount').value=computer.amount;
    document.getElementById('computerid').value=computer.id;
}
})();