'use strict';

const person = require('./person.json');

console.log(person);
console.log(person.firstname);
console.log(`${person.lastname}, ${person.firstname}`);

console.log(person.age);
let key='age';
console.log('a',person[key]);
key='member';
console.log('m',person[key]);

console.log(Object.keys(person));

console.log(Object.keys({a:1,b:2}));

const person2={
    //this can't be done in json file
    firstname:'Vera',
    "lastname":"River",
    notes:`vera's age is ${person.age}` //this takes age from person
};

console.log(person2);