
public class Fibonacci {
	
	public static void fibonacci(int number) {
	int a=0;
	int b=1;
		
		
			
			
			if(number>2) {
			for(int i=0;i<number;i++ ) {
				System.out.println(a);
				int c=a+b;
				a=b;
				b=c;
			
			}
			}
		
	}
	
	public static void main(String[] args) {
        
        
        try {
        	fibonacci(10);
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
