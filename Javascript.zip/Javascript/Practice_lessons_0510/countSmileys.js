'use strict';
function countSmileys(array){
    let count=0;
    /* 
    santhosh's way
    let smileTest = array.filter(a=>/[:|;][\-|\~]?[)|D]/.test(a));

return smileTest.length; */
//let array 2 with smileys
let array2=[':)',';)',':D',';D',':-)',';-)',':-D',';-D',':~)',';~)',':~D',';~D'];
console.log(array2);
let match=array.filter(a=>
    array2.includes(a)
);
console.log(match);
return match.length;
}

console.log(countSmileys([':)', ';(', ';}', ':-D']));       // should return 2;
console.log(countSmileys([';D', ':-(', ':-)', ';~)']));     // should return 3;
console.log(countSmileys([';]', ':[', ';*', ':$', ';-D'])); // should return 1;
