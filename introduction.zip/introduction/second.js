'use strict';

const a=10;
console.log(a);
//a=a+10; assign only one value to a constant else will get TypeError: Assignment to constant variable.
let b=18;
console.log(b);
b=b+10;
console.log(b);
let c = b-a;
console.log(c);
console.log('c=',c);
console.log('c='+c);
console.log('result is'+ a+b); //this is string concatenation since first one is string
console.log('result is'+ (a+b));
console.log(`result of ${a} + ${b} =${(a+b)}`);