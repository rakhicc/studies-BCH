# car library API

## **getWithLicence(licence)**
function gets the car object which has the given licence. A licence is unique.

-   if th car is found, returns the car object
-   if no car with given licence is found, returns null

## **getWithModel(model)**
returns all cars with given model
-   returns all matching cars as an array
-   if no car matches the given model, an empty array is returned

## **getAllModels()**
return names of all models in storage as an array of strings. The name
is added to the array only once.

-   returns an array of models
-   returns an empty array, if no models is found

## **getCar(key,value)**

get all cars that matches the given key-value pair.
-   returns car objects in an array
-   if there is no matches, an empty array is returned