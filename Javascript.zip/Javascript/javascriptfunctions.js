//function sum
function sum(x,y) {
    console.log('hello world');
    return x+y;
    
}
//function multiplication
function multiply(x,y) {
    console.log('hello world');
    return x*y;
    
}
'nice'.length;
console.log('nice'.length);
console.log(sum(2,5));
let b = 'language';
b.substring(0,3);
console.log(b.substring(0,3));
console.log(b.substring(4));