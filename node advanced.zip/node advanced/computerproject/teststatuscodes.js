'use strict';
const {CODES,TYPE, MESSAGES}=require('./storage/statuscodes');
console.log(MESSAGES.KEYS_DO_NOT_MATCH(10,245));

const result=MESSAGES.NOT_FOUND('id',2);
if(result.code===CODES.NOT_FOUND){
console.log('not')
}