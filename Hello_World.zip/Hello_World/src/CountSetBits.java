// Java program to Count set
// bits in an integer

 
class countSetBits {
    /* Function to get no of set
    bits in binary representation
    of positive integer n */
    static int countSetBits(int n)
    {
        int count = 0;
        while (n > 0) {
        	System.out.println(n & 1);
            count += n & 1;
            System.out.println("count "+count);
            System.out.println("n "+n);
            n >>= 1;
            System.out.println("n>>= "+n);
        }
        System.out.println("final count "+count);
        return count;
    }
 
    // driver program
    public static void main(String args[])
    {
        int i = 9;
        System.out.println(countSetBits(i));
    }
}
 