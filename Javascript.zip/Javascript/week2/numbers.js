'use strict';
console.log('epsilon',Number.EPSILON);
console.log('min value', Number.MIN_VALUE);
console.log('max value', Number.MAX_VALUE);
console.log('min Integer', Number.MIN_SAFE_INTEGER);
console.log('max integer', Number.MAX_SAFE_INTEGER);

console.log('NaN', Number.NaN);
console.log('NaN', NaN);
console.log(isNaN(43));
console.log(isNaN(NaN));
console.log(12/0);
console.log(0/0);
console.log(Number.isInteger(24));
console.log(Number.isInteger(2.5));

const valueA=2.6;
console.log(Math.ceil(valueA));
console.log(Math.floor(valueA));
console.log(Math.round(valueA));
console.log(Math.trunc(valueA));