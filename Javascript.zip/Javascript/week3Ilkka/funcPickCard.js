'use strict';
function randomcard(){
const suite=Math.floor(Math.random()*4);//number 0,1,2,or 3
const rank=Math.ceil(Math.random()*13)// 1 to 13
//other way using array of objcts
const suitesNew =[
    {symbol:'\u2660',color:'black'},
    {symbol:'\u2663',color:'black'},
    {symbol:'\u2665',color:'red'},
    {symbol:'\u2666',color:'red'}
    ];
    return console.log(` ${suitesNew[suite].symbol} ${rank} ${suitesNew[suite].color}`);
}
for(let i=0;i<5;i++){
    randomcard();
}