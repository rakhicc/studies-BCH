'use strict';

/**
Define a class (empty for now) that represents a recipe. Then create a new variable called recipe and
assign it to a new instance of that class.
**/


// class definition
class Recipe {
}


// class usage
let recipe = new Recipe();
console.log(recipe)
