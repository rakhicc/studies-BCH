/*
Complete the class User such that it contains the following instance methods:

getFullName which should return the following string: "fullname here".
canVote which should return true
hasVoted which should return false
*/

class User {
    constructor(firstName, lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
    getFullName(){
        return "fullname here";
    }
    canVote(){
        return true;
    }
    hasVoted(){
        return false;
    }
    // TODO:


}

// Class usage
let user = new User("Sam", "Doe");
console.log(user.canVote());
console.log(user.getFullName());
console.log(user.hasVoted());
// console.log(user.getFullName());
