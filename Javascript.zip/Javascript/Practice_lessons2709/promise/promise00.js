// idea is to go through promises topic as per revision request
