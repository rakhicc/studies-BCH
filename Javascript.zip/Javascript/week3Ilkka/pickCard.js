'use strict';
const suite=Math.floor(Math.random()*4);//number 0,1,2,or 3
const rank=Math.ceil(Math.random()*13)// 1 to 13
let symbol;
if(suite===0){
    symbol='\u2660';
} else if(suite===1){
    symbol='\u2663';
} else if(suite===2){
    symbol='\u2665';
}  else {
    symbol='\u2666';
}
console.log(`${symbol} ${rank}`);

//or else use array for symbols
const suites =['\u2660','\u2663','\u2665','\u2666']
console.log(`${suites[suite]} ${rank}`);

//other way using array of objcts
const suitesNew =[
{symbol:'\u2660',color:'black'},
{symbol:'\u2663',color:'black'},
{symbol:'\u2665',color:'red'},
{symbol:'\u2666',color:'red'}
];
console.log(`result from array ${suitesNew[suite].symbol} ${rank} ${suitesNew[suite].color}`);