/*
Implement the following instance methods for the class User:

getFullName such that it returns the first name and the last name of the user separated by a space character.
getInitials such that it returns the first character of the first name immediately followed by the first character of the last name.
canVote such that it returns true when the user is 18 years or above and false otherwise.
*/

class User {
  constructor(firstName,lastName,age){
    this.firstName=firstName;
    this.lastName=lastName;
    this.age=age;
  }
  //TODO
  getFullName(){
    return `${this.firstName} ${this.lastName}`;
  }
  getInitials(){
    return `${this.firstName[0]}${this.lastName[0]}`;
  }
  canVote(){
    
      return this.age>=18;
   
  }
}



// class usage
let sam = new User("Sam", "Blue", 49);
console.log(sam.getFullName());
console.log(sam.getInitials());
console.log(sam.canVote());
// TODO: use the methods as you define them

let charlie = new User("Charlie", "Doe", 13);
// TODO: use the methods as you define them

console.log("---");
