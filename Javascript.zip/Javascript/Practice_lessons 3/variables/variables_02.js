'use strict';
//define a variable "ageLimit" with value 18 that cannot be re-assigned
//Define a variable ageLimit that cannot be re-assigned and give it a value of 18.
