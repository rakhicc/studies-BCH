# Markdown file format

- https://en.wikipedia.org/wiki/Markdown
- https://www.markdownguide.org/


# Example

## preview
-   apple
    -   cmd+shift+v
-   windows
    -   ctrl+shift+v

## Headers

# level 1 header
## level 2
### level 3
#### level 4
##### level 5
###### level 6

## text formatting

Some text *this is italic* **this is bold** `code`  
two spaces at the end of line results a linefeed

this is a third line

## Blockquoting
>this is first level
>>this is the nested level¨
>>>this is third level

## Lists
-   item 1
*   item 2
    -   subitem

## Numbered lists
1.  item 1
2.  item 2

## Javascript

```js
const a=10;
let b='something';
```

<div style="page-break-after:always;"></div>

## Forced page break in pdf
```html
<div style="page-break-after:always;"></div>
```

## css
```css
p {
    color:red;
}
```

## json file
```json
{
    "firstname":"Matt",
    "lastname":"River"
}
```

## grey area
```
block
```
## terminal /shell
```shell
>node -v
```

## Links
To create a link, enclose the link text in brackets (e.g., [Duck Duck Go]) and then follow it immediately with the URL in parentheses (e.g., (https://duckduckgo.com)).

My favorite search engine is [Duck Duck Go](https://duckduckgo.com)

## URLs and Email Addresses
To quickly turn a URL or email address into a link, enclose it in angle brackets.

<https://www.markdownguide.org>
<fake@example.com>