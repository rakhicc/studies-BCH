'use strict';


const http = require('http');
const path=require('path');
if(process.argv.length<4){
    console.log("usage:node server <port> jsonfile  Example:node server 3000 data.json")
} else{
    try{
const [,,port,datafilename]=process.argv;

const data =require(path.join(__dirname,datafilename));
console.log(data);
const host="localhost";
const server=http.createServer((request,response)=>{
    response.writeHead(200, {
        'Content-Type':'application/json',
        'Access-Control-Allow-Origin':'*'
    });
    response.end(JSON.stringify(data));
});
    server.listen(port,host,()=>console.log(`server ${host}:${port} listening`));

    }
     catch(error){
        console.log('file not found');
    }
}




