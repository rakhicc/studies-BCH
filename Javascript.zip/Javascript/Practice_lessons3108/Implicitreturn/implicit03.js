'use strict';

/**
Complete the function getPositiveTemperatures such that it returns an array containing the positive temperatures (the temperatures that are above 0).
Use an arrow function (implicit return is optional).
/**
 * @param {number} value
 */
/* function getPositiveTemperatures () {

} */
const positivetemp=(arrays)=>arrays.filter(function(array) {
    return array>=0;
});

const positivetempagain=(arrays)=>arrays.filter(array=>array>=0)


// Sample usage - do not modify
console.log(positivetempagain([2, -4])); // 2,4
console.log(positivetempagain([3, -3,-4,3,0])); // 3,3
