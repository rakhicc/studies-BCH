this projet is to study the ci/cd using jenkins
