// 1 - Select the section with an id of container without using querySelector.
const getSectionContainer = () => {
const container= document.getElementById("container");
return container;
}

// Sample usage - do not modify
console.log(getSectionContainer());


// 2 - Select the section with an id of container using querySelector.

const getSectionContainerUsingQuery = () => {
    const container= document.querySelector("#container");
    return container;
}

// Sample usage - do not modify
console.log(getSectionContainerUsingQuery());

// 3 - Select all of the list items with a class of "second".

const getListItems = () => {
    const container= document.querySelectorAll(".second");
    return container;
}

// Sample usage - do not modify
console.log(getListItems());


// 4 - Select a list item with a class of third, but only the list item inside of the ol tag.

const getListItemsThird = () => {
    const container= document.querySelector("ol .third");
    return container;
}

// Sample usage - do not modify
console.log(getListItemsThird());


// 5 - Give the section with an id of container the text "Hello!".

const giveSectionContainerID = () => {
    const container= document.querySelector("#container");
    return container.textContent="Hello!";
}

// Sample usage - do not modify
console.log(giveSectionContainerID());


// 6 - Add the class main to the div with a class of footer.

const addClassMainToDiv = () => {
    const container= document.querySelector(".footer");
     container.classList.add("main");
}

// Sample usage - do not modify
console.log(addClassMainToDiv());


// 7 - Remove the class main on the div with a class of footer.

const removeClassMainToDiv = () => {
    const container= document.querySelector(".footer");
    container.classList.remove("main");
}

// Sample usage - do not modify
console.log(removeClassMainToDiv());



// 8 - Create a new li element.

const createliElements = () => {
const li =document.createElement("li");
return li;
}

// Sample usage - do not modify
console.log(createliElements());


// 9 - Give the li the text "four".

const giveliText = () => {
    const li =document.createElement("li");
    li.textContent="four";
    return li;
}

// Sample usage - do not modify
console.log(giveliText());


// 10 - Remove the div with a class of footer.

const removeDiv = () => {
document.querySelector(".footer").remove();
}

// Sample usage - do not modify
console.log(removeDiv());
