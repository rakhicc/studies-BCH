// you can also use imports, for example:
// import java.util.*;

// you can write to stdout for debugging purposes, e.g.
// System.out.println("this is a debug message");

class TaskOne {
    public String solution(String S, int[] A) {
        // write your code in Java SE 8

        char[] characters=S.toCharArray();
        int finalPerson=A[0];
        String message=String.valueOf(characters[0]);
        while(finalPerson !=0){
            message+= characters[finalPerson];
            finalPerson=A[finalPerson];
        }
        return message;
        
    }
}
