# to do list app using HTML,CSS and javascript
- the to do app is created using HTML,CSS,Javascript

# Functionalities
- We can add a new item to the to do list by clicking on add button
- An item can be deleted by clicking on close button
- An item can be moved to done list by clicking on the Done button
- By clicking on delete All button all items in the to do list will be deleted.