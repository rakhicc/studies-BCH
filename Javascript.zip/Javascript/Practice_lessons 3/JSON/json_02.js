'use strict';

/**
Complete the prepareStatus function such that it returns a string of the data that's going to be sent,
containing the userId, status, and location.

 * @param {string} status
 * @param {string} location
 */
const prepareStatus = (status, location) => {
    const jsonObject = {
        userId : 42,
        status : `${status}`,
        location : `${location}`
    }
    const jsonString = JSON.stringify(jsonObject);
    return jsonString;
}

// Sample usage - do not modify
console.log(prepareStatus("My first post!", "Amsterdam")); // '{"userId":42,"status":"My first post!","location":"Amsterdam"}'
console.log(prepareStatus("Hello World!", "Berlin")); // '{"userId":42,"status":"Hello World!","location":"Berlin"}'
