import React from 'react'

function Cello({row,col}) {
    
    return (
        <div className="ob" id={`${row}-${col}`}>
            
        </div>
    )
}

export default Cello
