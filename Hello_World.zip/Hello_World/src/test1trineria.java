import java.util.*; 
import java.io.*;

class Main {
	//Find the longest substring with k unique characters in a given string
final static int MAX_CHARS=26;

// function which calculates number of unique characters.
static boolean isValid(int count[],int k){
  int val=0;
  for(int i=0;i<MAX_CHARS;i++){
    if(count[i]>0){
      val++;
    }
  }
  //return true if k is greater than or equal to k
  return(k >= val);
}
  public static String SearchingChallenge(String str) {
    // code goes here 
    int k=Integer.parseInt(str.substring(0,1)) ;
    String s=str.substring(1,str.length());
    //System.out.println(s);
    int u=0;
    int n=s.length();
    //array to store count of characters
int count[]=new int[MAX_CHARS];
Arrays.fill(count,0);
for(int i = 0;i <n ; i++){
  if(count[s.charAt(i) - 'a'] == 0){
    u++;
  }
  count[s.charAt(i) - 'a']++;
}
//if there are not enough unique characters return a message showing the same
if(u < k){
   System.out.println("Not enough unique characters");
  
}
//otherwise take a window with first element in it. start and end variables.
int curr_start=0,curr_end=0;
//initialise value for longest window
int max_window_size=1;
int max_window_start=0;
Arrays.fill(count,0);
count[s.charAt(0) - 'a']++;
for(int i=1; i<n; i++) {
  count[s.charAt(i) - 'a']++;
  curr_end++;

//if there are more than k unique characters in window remove from left side
while(!isValid(count,k)){
  count[s.charAt(curr_start) - 'a']--;
  curr_start++;
}
//update the maximum window size if required
if(curr_end - curr_start + 1 > max_window_size){
  max_window_size=curr_end - curr_start + 1;
  max_window_start=curr_start;
}
}
    return s.substring(max_window_start,max_window_start+max_window_size);
  }

  public static void main (String[] args) {  
    // keep this function call here     
    Scanner s = new Scanner(System.in);
    System.out.print(SearchingChallenge(s.nextLine())); 
  }

}