const getFooterElement = () => {
  console.log(document.querySelector('#footer-wrapper'));
  return document.querySelector('#footer-wrapper');
}
// Sample usage - do not modify
console.log(getFooterElement());
