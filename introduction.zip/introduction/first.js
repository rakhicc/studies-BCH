'use strict';

// this is a comment
/* this is for
block command */

console.log('hello world');