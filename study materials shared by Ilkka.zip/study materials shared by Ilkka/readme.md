# Software installations

- node
    - nodejs.org
    
-vscode / vscodium
    - https://code.visualstudio.com/
    - https://vscodium.com/