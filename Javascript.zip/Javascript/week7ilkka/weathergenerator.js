'use strict';

const data=[];
const rainAmount=[0,0.5,2,10,20];
const cloudSymbols=['\u2600','\u26C5','\u2601','\u2602','\u26C8'];
for (let i=1; i<=31;i++){
    const randTemp=Math.round(Math.random()*30);
    const randRain=Math.floor(Math.random()*rainAmount.length);
data.push({
    day:i,
    temp:randTemp,
    rain:randRain,
    cloud:randRain,
    cloudSymbol:cloudSymbols[randRain]
})

}
console.log(JSON.stringify(data,null,2));

