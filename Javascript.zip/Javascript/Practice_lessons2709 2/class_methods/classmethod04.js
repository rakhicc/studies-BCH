/*
Implement the instance method getFullName such that it returns the first name
and the last name of the user separated by a space character.
*/

class User {
   constructor(firstName, lastName) {
       this.firstName = firstName;
       this.lastName = lastName;
   }
   //TODO
   getFullName(){
       return `${this.firstName} ${this.lastName}`;
   }


}


// class usage
let sam = new User("Sam", "Blue");
console.log(sam.getFullName());

let charlie = new User("Charlie", "Doe");
console.log(charlie.getFullName("Charlie", "Doe"));

console.log("---");
