'use strict';

const [,,...data]=process.argv;

// console.log(data);

let sum=0;
for(let number of data){
    sum = sum + (+number) //sum += +number;
    // console.log(sum);
}
console.log(`sum is ${sum}`);
console.log(`avg is ${sum/data.length}`);
console.log(`sum of ${data.join(' + ')} = ${sum}`);