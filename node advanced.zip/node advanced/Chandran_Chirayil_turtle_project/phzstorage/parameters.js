'use strict';
const toArrayInsert=nps=>[
    +nps.employeeid,nps.date,+nps.score,
    nps.feedback
]

module.exports={toArrayInsert};
