# Books library API

## **getBooksOfPerson(firstname,lastname)**
-   function returns all book objects of a person.
-   if person has no books, an empty array is returned

## **getTheNamesOfBooks(firstname, lastname)**
-   return an array of book names of books belonging to given person
-   if person has no books, en empty array is returned