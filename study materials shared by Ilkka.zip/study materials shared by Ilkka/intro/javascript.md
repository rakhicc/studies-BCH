# Javascript basics

-   javascript laguage
    - ecmascript 2015- (ES6)
    -   https://www.ecma-international.org/publications-and-standards/standards/ecma-262/
    -   https://developer.mozilla.org/en-US/docs/Web/JavaScript/

-   other technologies
    -   https://developer.mozilla.org/en-US/docs/Web/
    -   https://www.w3.org
    -   https://html.spec.whatwg.org/multipage/

- JSON (Javascript Object Notation)
    -   https://www.json.org


# First.js

```js
'use strict';

// this is a comment that end to the end of this line

/* this is a block comment that can continue to sext lines
this is still commented
*/

console.log('Hello world!');
```

### to run the program
Open **terminal**
```shell
> node first
Hello world!
```
