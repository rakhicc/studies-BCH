const getArticleTitle = () => {
return headline=document.querySelector("#headline")?.textContent;

}

// Sample usage - do not modify
console.log(getArticleTitle()); // "First human lands on Mars!"
