'use strict';

/**
Complete the checkForNewNotifications function such that it makes a fetch request to https://jsdemo-3f387-default-rtdb.europe-west1.firebasedatabase.app/notifications/new.json
and return its result.
**/

const checkForNewNotifications = () => {

}


// Sample usage - do not modify
const result = checkForNewNotifications();
console.log(result); // Promise{<pending>}
