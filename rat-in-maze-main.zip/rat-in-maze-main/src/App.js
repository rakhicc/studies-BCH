
import './App.css';
import Table from './components/Table'
function App() {
  return (
    <div className="App">
      <div className="obj"></div>
      <h2 className="head"> This block indicates the obstacles </h2>
      <Table/>
    </div>
  );
}

export default App;
