# learning CI/CD

<p align="center">
  <img src="https://img.shields.io/badge/CI/CD-batch-brightgreen" />
  
</p>
