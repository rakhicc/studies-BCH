'use strict';

const a=10;

console.log(a);
console.log(20);
console.log(a+50);
console.log(a);
//a=a+10; //causes an error

let b=80;
console.log(b);
b=b+100;
console.log(b);

let c = b - a;
console.log('c=',c);
console.log('c= '+c);
console.log('result is '+ a + b);
console.log('result is ' + (a + b));

console.log(`Result of ${c} + ${b} = ${(c+b)}`);
