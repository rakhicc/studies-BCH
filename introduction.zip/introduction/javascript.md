# Javascript basics

- javascript langage
  - 2015