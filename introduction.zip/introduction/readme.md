# heading 1
## heading 2

this is first line  
this is second line

*this is italic*  
**this is bold**  
this is ***really important*** text

# Block quotes
> this is within block quotes
>
>hi I am rakhi

## Nested block quotes can be added using >>
> main quote
>> nested block quote

## Lists

### ordered lists

1. item 1
2. item 2

### unordered Lists

- item 1
- item 2 

### unordered list

* item 1
* item2

## json file
```json
{
    "firstname":"Matt",
    "lastname":"River"
}
```

## grey area
```
block
```

## Javascript
```javascript
const a=10;
let b=3:
```

## css
```css
p {
    color:red;
}
```
## terminal/shell

```shell
>node-v
```

## Links
To create a link, enclose the link text in brackets (e.g., [Duck Duck Go]) and then follow it immediately with the URL in parentheses (e.g., (https://duckduckgo.com)).

My favorite search engine is [Duck Duck Go](https://duckduckgo.com)

## URLs and Email Addresses
To quickly turn a URL or email address into a link, enclose it in angle brackets.

<https://www.markdownguide.org>
<fake@example.com>

