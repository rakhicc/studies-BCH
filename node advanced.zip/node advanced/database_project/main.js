'use strict';
const {getAll,get,add,update,remove}=require('./databaselayer');
async function run(){
    console.log('printing in the order the methods are called');
    await getAll();
    await get(1);
    await get(2);
    console.log('remove ####');
    await remove(9000);
    const newEmp={
        employeeId:9000,
firstname:'Jones',
lastname:'James',
department:'ECE',
salary:2000
}
console.log('add')
    await add(newEmp);
    const updateEmp={
        employeeId:1,
firstname:'rakhi',
lastname:'cc',
department:'ECE',
salary:2000
}
await update(updateEmp);
}
run();