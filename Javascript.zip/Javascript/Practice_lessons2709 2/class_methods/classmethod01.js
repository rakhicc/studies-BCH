class User {
    constructor(firstName, lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
    canVote(){
      console.log('can vote method');
    };
  //TODO: Complete the class definition below such that it defines
  //an instance method called canVote. 
}
let user=new User('rakhi','chandran');
user.canVote();
