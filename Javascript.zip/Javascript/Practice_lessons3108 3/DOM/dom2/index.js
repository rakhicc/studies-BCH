const getNavbarElement = () => {
    // TODO: get the element with id navbar
}

const getMainElement = () => {
    // TODO: get the element with id main
}

const getAboutFromFooter = () => {
    // TODO: get the the about link that's in the footer

}

const getTheParagraphElement = () => {
    // TODO: get the first paragraph element

}


// Sample usage - do not modify
console.log(getNavbarElement());
console.log(getMainElement());
console.log(getAboutFromFooter());
console.log(getTheParagraphElement());
