'use strict';
(function(){
 document.addEventListener('DOMContentLoaded',init); 
 async function init(){
     console.log("rakhi");
const data = await fetch('http://localhost:3000',{mode:'cors'});

const jsondata=await data.json();
console.log(jsondata.firstname);
document.getElementById("firstname").textContent=jsondata.firstname;
document.getElementById("lastname").textContent=jsondata.lastname;
 }
}
)();