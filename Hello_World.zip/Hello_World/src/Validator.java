import java.util.Scanner;

class Valid {
    public boolean validate(String name) {
        for (int i = 0; i < name.length(); i++) {
            char ch = name.charAt(i);
            System.out.println(ch);
            System.out.println(Character.isLowerCase(ch));
            System.out.println(Character.isUpperCase(ch));
            if (ch != ' ' && !(Character.isLowerCase(ch) || Character.isUpperCase(ch))) {
                return false;
            }
        }
        
        return true;
    }
}
class Encrypter {
    public static String getEncryptedName(String name) {
                // if (name != null){
    	Valid myValidator = new Valid();
                if (myValidator.validate(name)){
                    //String lowercase =  new String(name).toLowerCase();
                    //System.out.println(lowercase);
                    //System.out.println(new StringBuilder(lowercase));
                    StringBuilder output = new StringBuilder(name).reverse();
                    //new StringBuilder(output);
                    return output.toString().toLowerCase();
                    // name.toLowerCase();
                    // return name
                } else {
                    throw new IllegalArgumentException("Try again with valid name");
            }
    }
}
public class Validator {
    private static final Scanner INPUT_READER = new Scanner(System.in);
    
    public static void main(String[] args) {
        String name = INPUT_READER.nextLine();
        
        try {
            System.out.println(Encrypter.getEncryptedName(name));
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}