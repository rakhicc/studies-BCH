'use strict';
const library=require('./books.json');

for(let person of library){
    let sum=0;
for(let book of person.books){
    console.log(`${book.name}  ${book.price}`);
    sum=sum+book.price;
}
console.log(`=========total sum is${sum}`);

}

