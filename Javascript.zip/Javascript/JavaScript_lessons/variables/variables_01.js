//define a variable "count" with value 0
// Define a variable called count with an original value of 0 and then increment it (add 1 to it) on the following line.

//define a variable "count" with value 0
let count = 0;
//then increment it
count = count + 1; // or count += 1
