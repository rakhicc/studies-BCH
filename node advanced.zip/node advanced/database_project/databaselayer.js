'use strict';
const Mariadb=require('./database');
const options={
    host:'localhost',
    port:3306,
    user:'zeke',
    password:'secret',
    database:'employeedb',
    allowPublicKeyRetrieval:true
    };
    const db=new Mariadb(options);
    //db.doQuery('select * from employee').then(console.log).catch(console.log);
function printworkers(employees){
    for(let person of employees){
        console.log(`hello ${person.employeeId}:${person.firstname}:${person.lastname}`+
        `Dept:${person.department},:${person.salary}€`);
    }
}
    async function getAll(){
        try{
const result=await db.doQuery('select * from employee');
if(result.resultSet){
    
    printworkers(result.queryResult);
}
        } catch(error){
            console.log(error);
        }
    }
async function get(id){
    try{
const result=await db.doQuery('select * from employee where employeeId=?',[id]);
printworkers(result.queryResult);
    }catch(error){
        console.log(error);
    }
}
  async function add(person){
      try{
/* const parameters=[
    person.employeeId,
    person.firstname,
person.lastname,
person.department,
person.salary]; */
const parameters=Object.values(person);
const sql='insert into employee values(?,?,?,?,?)';
const status=await db.doQuery(sql,parameters);
console.log('status',status);
      }catch(error){
          console.log(error);
      }
  } 
  async function remove(id){
      try{
      const sql='delete from employee where employeeId=?';
      const status=await db.doQuery(sql,id);
      console.log('removed successfully');
    }
      catch(error){
          console.log(error);
      }
  }
  async function update(person){
    try{
        const sql='update employee set firstname=?, lastname=?, department=?, salary=? where employeeId=?';
      const parameters=[
          person.firstname,
          person.lastname,
          person.department,
          person.salary,
          person.employeeId
      ];
      const status = await db.doQuery(sql,parameters);
    }catch(error){
        console.log('update error',error);
    }
  }
    module.exports={getAll,get,add,update,remove}