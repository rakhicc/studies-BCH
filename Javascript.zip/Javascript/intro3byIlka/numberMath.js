console.log(isNaN(12));
console.log(isNaN('a'));
console.log(isNaN(NaN));
console.log(12/0);
console.log(0/0);
console.log(Number.isInteger(12.5));
console.log(Number.isInteger(12));
console.log(Number.isInteger(-12));
console.log(Number.MAX_VALUE);
console.log(Number.MIN_VALUE);
console.log(Number.MAX_SAFE_INTEGER);
console.log(Number.MIN_SAFE_INTEGER);

//floor and truncc are similiar always round the number to lowest integer
//round will round to up and down based on the fractional part
//ceil will move to next higher integer
 const value=2.4;
 console.log(Math.ceil(value));
 console.log(Math.floor(value));
 console.log(Math.trunc(value));
 console.log(Math.round(value));
 const value1=2.6;
 console.log(Math.ceil(value1));
 console.log(Math.floor(value1));
 console.log(Math.trunc(value1));
 console.log(Math.round(value1));
