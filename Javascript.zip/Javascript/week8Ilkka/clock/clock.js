'use strict';
(function(){

let drawingArea;
let context;
let timer;
let angleInRadians;
let backgroundcolor;
document.addEventListener('DOMContentLoaded',init);
function init(){
    console.log('reached start');
    drawingArea=document.getElementById("drawingArea");
    context=drawingArea.getContext('2d');
    backgroundcolor=context.createRadialGradient(200,200,200,200,200,50);
    backgroundcolor.addColorStop(0.0, 'green');
    backgroundcolor.addColorStop(0.5, 'greenyellow');
    backgroundcolor.addColorStop(1.0, 'lightgreen');
    angleInRadians=0;
    timer=setInterval(update, 1000);
    update();



}
function update(){
    console.log('reached update');
    context.fillStyle=backgroundcolor;
    context.fillRect(0,0,drawingArea.width,drawingArea.height);
context.save();
context.translate(200,200);
context.filllStyle='orange';
angleInRadians+=6*Math.PI/180;
context.rotate(angleInRadians);
context.fillRect(0,-5,190,10);

context.save();
context.font='20pt Serif';
context.strokeStyle='black';
context.strokeText('the time is', 10, -7);
context.restore();

context.arc(0,0,10,0,2*Math.PI);
context.fill();
context.stroke();
context.restore();






}

})();