const getFullName = () => {
    const frstnm=document.querySelector("#first-name").value;
    const lastnm=document.querySelector("#last-name").value;
    return `${frstnm} ${lastnm}`;

}

// Sample usage - do not modify
const fullName = document.querySelector("#full-name");
const firstName = document.querySelector("#first-name");
const lastName = document.querySelector("#last-name");

const updateFullName = () => {
    fullName.textContent = getFullName();
}
firstName.addEventListener("keyup", () => updateFullName());
lastName.addEventListener("keyup", () => updateFullName());
