'use strict';
const toArrayInsert=computer=>[
    +computer.id,computer.name,computer.type,computer.processor,
    +computer.amount
]
const toArrayUpdate=computer=>[
    computer.name,computer.type,computer.processor,
    +computer.amount,+computer.id
]
module.exports={toArrayInsert,toArrayUpdate};
//returns an array for ex:[100,'abc','laptop','x1z',23