# JSON (JavaScript Object Notation)

## Documentation
json.org

## File extension
.json

## Values
-   strings
-   numbers
-   arrays
-   objects
-   true
-   false
-   null

## Exapmles

### String
Must be doublequoted
empty string:
""

```json
"this is a string"
"Here is a \"quote\" in the middle"
"hearts symbol is \u2665"
```

outputs:
```
this is a string
Here is a "quote" in the middle
hearts symbol is ♥
```

### Number
-   no leadeading +
-   only 1 leading 0
-   decimal separator is .

These are allowed:
```json
0, 0.5, 345.678, 1200, 1.5E10, 2E-2, -2E+4, -1, -11.5, -0.567
```

These are not allowed:
```json
000.34, +20, 00030
```

## Array
Array begins with [ and ends with ]. Value in the array is separated by a comma

### Exaples
```json
[1,2,3,4,5]
["textA","textB"]
[{ "firstname":"Matt","lastname":"River"},{ "firstname":"Vera",
    "lastname":"River"}]
[true,null,false]
[[1,2,3],[4,5,6]]
```

## Object
An object begins with { and ends with }. The object consists of comma separated key-value pairs. The key and value are separated by colon :

```json
{
    "firstname":"Matt",
    "lastname":"River"
}

{
    "firstname":"Leila",
    "children":[
        {"firstname":"Vera"},
        {"firstname":"Jesse"}
    ]
}

{
    "key1":"value1",
    "key2":"value2",
    "key3":[1,2,3],
    "key4":{
        "a":1,
        "b":"text",
        "c":[8,9,7],
        "d":{
            "x":true,
            "y":false,
            "z":null,
            "w":2
        }
    }
}
```