'use strict';

const { 
    getWithLicence, 
    getWithModel,
    getAllModels,
    getCar
 } = require('./carstorage');

console.log(getCar('model','Errare'));
console.log(getCar('licence', 'A-1'))
console.log(getCar('model','x'));
console.log(getWithLicence('ABC-1'));
console.log(getWithModel('MbWx'));

for(let car of getWithModel('Fast GT')){
    console.log(car.licence);
}

console.log(getAllModels());
console.log(`\nAll available models:\n\t${getAllModels().join('\n\t')}`);