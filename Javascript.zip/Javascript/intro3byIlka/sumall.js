const [,,...numberarray] =process.argv;
console.log(numberarray);
let sum =0;
for (let number of numberarray){
    sum += Number(number) // to convert the string or character to number we can also use +number
console.log(sum);
}
console.log('average is ',sum/numberarray.length);
console.log(`sum is ${numberarray.join(' + ')} = ${sum}`);