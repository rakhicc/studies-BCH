'use strict';

const library = require('./books.json');

console.log(library[0].books[0].name);
console.log('##########');
for(let book of library[0].books){
    console.log(book.name);
}
console.log('##########');
for (let book of library[1].books) {
    console.log(book.name);
}
console.log('##########');
for(let person of library){
    for(let book of person.books){
        console.log(book.name);
    }
}

console.log('##########');
for (let person of library) {
    console.log(`${person.firstname} ${person.lastname}`);
    for (let book of person.books) {
        console.log('\t'+book.name);
    }
}

console.log('##### total price #####');
let sumOfWholeLibrary=0;
for(let person of library){
    console.log(`${person.firstname} ${person.lastname}`);
    let totalSum=0;
    for(let book of person.books){
        totalSum+=book.price;
        console.log(`\t${book.name}, ${book.price} €`)
    }
    console.log('================')
    console.log(`Total price: ${totalSum} €\n`);
    sumOfWholeLibrary+=totalSum;
}
console.log(`Grand total: ${sumOfWholeLibrary} €`);

console.log('#### total pages per person');
for(let person of library) {
    let sumOfPages=0;
    for(let book of person.books){
        sumOfPages+=book.pages;
    }
    console.log(`${person.firstname} ${person.lastname}: ${sumOfPages} pages`);
}

console.log('#### total pages and tota price per person');
for (let person of library) {
    let sumOfPages = 0;
    let totalPrice=0;
    for (let book of person.books) {
        sumOfPages += book.pages;
        totalPrice+=book.price;
    }
    console.log(`${person.firstname} ${person.lastname}:`+
    ` ${sumOfPages} pages (${totalPrice} €)`);
}

