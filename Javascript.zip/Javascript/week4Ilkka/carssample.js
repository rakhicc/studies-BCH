'use strict';


const carsjson=require('./cars.json')


function getwithmodel(model){
const carwithmodel=carsjson.filter(car=>car.model===model);
return carwithmodel;
}
//console.log(getwithmodel('abc'));
function getAllModels(){
    const models =[];
    for(let car of carsjson){
        
        models.push(car.model);
    }
    return models;
}
function getcar(key,value){
    const found=[];
    for(let car of carsjson){
        if(car[key]===value){
            found.push(car);
        }
    }
    return found;
}
//console.log(getAllModels(carsjson));
module.exports={getwithmodel,getAllModels,getcar};