import React from "react";
import styles from "./GraphPage.module.css";
import Header from "../Header";

const GraphPage = ({ data }) => {
  return (
    <div>
      <Header />
    </div>
  );
};

export default GraphPage;
