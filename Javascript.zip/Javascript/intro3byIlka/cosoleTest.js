'use strict';
//console.log(process.argv);
//console.log(process.env);
const [first,second,...rest]=process.argv;
console.log(first);
console.log(second);
console.log(rest);
