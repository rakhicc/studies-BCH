# cards
give the card suite as text from inputline (spade,clubs, hearts, diamond)

program prints out the suite symbol

'\u2660', \u2663', \u2665', \u2666'

output hint:
`${suite}`

