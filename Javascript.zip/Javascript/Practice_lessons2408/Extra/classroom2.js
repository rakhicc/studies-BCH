'use strict';

/**
Task 1;
let myAlphabet = ['A', 'B', 'C', 'D','E','F', 'G'];
What is the length of the array?
Write a function called myAlphabetLength which console.logs the length of the array
Within the function also use an if-conditional statement that checks if the number of items within the array are less than 5
**/
function myAlphabetLength(){
   let myAlphabet = ['A', 'B', 'C', 'D','E','F', 'G'];
    console.log(myAlphabet.length);
    if(myAlphabet.length <5) {
      console.log('array length is less than 5');
       return true;
      
   }
   console.log('array length is greater than 5');
    return false;   
    
}
myAlphabetLength();

/**
Task 2;
Declare a arrow function checkFunc that takes a string and a boolean as parameters
Call the function using 2 arguments
**/

const checkFunc=(string,boolean) => {

}
checkFunc('string',true);

/**
Task 3;
Declare and initialize an array called Planets with 5 string values
console.log each item in the array
Also console.log the index in each iteration
**/
const Planets =['uranus','jupiter','mercury','pluto','neptune'];
Planets.forEach(function (Planet) {
   console.log(Planets.indexOf(Planet));
   return console.log(Planet);
   
});
Planets.forEach(function (Planet) {
   return console.log(Planets.indexOf(Planet));
   
});
/**
Task 4:

Declare and initialize an array called wowDatatypes
The array must have 5 different data types (NOT objects)
Iterate over the array and console.log each item in the array + it’s index and data type in the array
**/

const wowDatatypes = ['a',2,true,null,undefined];
wowDatatypes.forEach(function(wowDatatype) {
   return console.log(`${wowDatatype} index is ${wowDatatypes.indexOf(wowDatatype)} and datatype is ${typeof(wowDatatype)}`);

});
const wowDatatypesagain = ['a',2,true,' ',3.14];
let wowdatatypeitem=wowDatatypesagain.forEach((item,index)=>{
return console.log(`${item} +${index} `+typeof(item));
});

/**
const
Task 5:
console.log each item in this array WITHOUT using a for loop
   let myArr = [ 1, 2, 'One', true];
**/
/* const myArr1 = [ 1, 2, 'One', true];
myArr.forEach(function (myArr) {
   return console.log(myArr);
   
}); */
/**
Task 6:
let student1Courses = ['Math', 'English', 'JSProgramming'];
let student2Courses = ['Geography', 'Spanish', 'JSProgramming'];
Loop over the 2 arrays and if there are any common courses, if so console.log them
**/
const commonArray=(array1Items,array2Items) => {
   let newArray= array1Items.filter(function(array1Item) {
      return array2Items.indexOf(array1Item) !== -1;
   });
   return newArray;
}
console.log(commonArray(['Math', 'English', 'JSProgramming'],['Geography', 'Spanish', 'JSProgramming']))
/*

Task 7:
let furniture = ['Table', 'Chairs','Couch'];
For each item in this array console.log the letters in each item
**/
const furnitureArrayitemletter=(arrayItems1) => {
   
   arrayItems1.forEach(function(arrayItem1) {
      
      for (let index = 0; index < arrayItem1.length; index++) {
        console.log(arrayItem1[index]);
         
         
      }
     
      
   });
   return 'characters in strings are returnde';
//
}
console.log(furnitureArrayitemletter(['Table', 'Chairs','Couch']));