'use strict';
const Database=require('./database');
let file='./createStatements.json';
if(process.argv.length>2){
    file=`./${process.argv[2]}`;

}

try{
dropdatabase(require(file));
}catch(error){
    console.log(`error:${error.message}`);
}

async function dropdatabase(statements){
    const dropOptions={
        host:statements.host,
        port:statements.port,
        user:statements.admin,
        password:statements.adminpassword
    }
    const dropdatabaseSql=`drop database if exists ${statements.database}`;
    const dropUserSql=`drop user if exists '${statements.user}'@'${statements.host}'`;

    const db=new Database(dropOptions);
    try{
        const sqls=[];
        sqls.push(db.doQuery(dropdatabaseSql));
        if(statements.dropuser){
            sqls.push(db.doQuery(dropUserSql));
        }
        await Promise.all(sqls);
        console.log('done');

    }catch(err){
    console.log(err.message);
        }


}
