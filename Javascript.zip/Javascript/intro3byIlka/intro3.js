'use strict';
//binary starts with 0b
const num=0b1011111;
console.log(num);

/* //octa starts with 0
const octa =020;// not work in strict mode
console.log(octa); */


const octal =0o20;// not work in strict mode to work 0o should be at starting
console.log(octal);
// hexa start with ox
const hex=0xFF;
console.log(hex);
console.log(num.toString(16).toUpperCase());// converting to hexa and octa
console.log(num.toString(8).toUpperCase());
console.log(num.toString(2).padStart(8,'0')); //to add zeros in the front to make total length as 8

// unicode characters
console.log('\u2663');
console.log(String.fromCodePoint(0x1f680));//use 0x in the front if unicode character is hexa

console.log(String.fromCodePoint(0x1f680,0x2663));
const smileface=String.fromCodePoint(0x1f642);
console.log(smileface);
//object
const symbols ={
    smileface :String.fromCodePoint(0x1f642),
    rocket:String.fromCodePoint(0x1F680)

};

console.log(symbols);
console.log(symbols.smileface);
console.log(symbols['rocket']);
let symb ='rocket'
if (symb==='smileface'){
    console.log(`smileface = ${symbols.smileface}`);
}
    else if (symb==='rocket'){
        console.log(`rocket = ${symbols.rocket}`);
    }
//in javascript we cann add new fields to the object at any time
symbols.flowers=String.fromCodePoint(0x1f490);
console.log(symbols.flowers);
console.log(Object.keys(symbols));
console.log(Object.values(symbols));

const [first,second,symbolname]=process.argv;
console.log(`${symbolname} as symbol ${symbols[symbolname]}`);