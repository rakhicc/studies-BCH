'use strict';

//console.log(process.argv);

// const [first,second,...rest]=process.argv;
// console.log(first);
// console.log(second);
// console.log(rest);

const [,,symbolname]=process.argv;
//symbolname=process.arv[2]

// console.log(symbolname);


const symbols = { 
    smileyFace: String.fromCodePoint(0x1F642),
    rocket: String.fromCodePoint(0x1F680),
    flowers: String.fromCodePoint(0x1F490)
};

console.log(`${symbolname} as symbol ${symbols[symbolname]}`);