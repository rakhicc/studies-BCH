'use strict';

// this is a comment that end to the end of this line

/* this is a block comment that can continue to sext lines
this is still commented
*/

console.log('Hello world!');



