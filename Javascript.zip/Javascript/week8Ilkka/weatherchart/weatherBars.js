'use strict';
(function(){
    document.addEventListener('DOMContentLoaded',init);
    async function init(){
        const data =await fetch('http://localhost:3000',{mode:'cors'});
        const jsondata=await data.json();
        
        drawBars(jsondata);

    }
    function drawBars(tempdata){
        const chartArea=document.getElementById("drawingArea");
        const context=chartArea.getContext('2d');
        context.translate(10,150);
        drawGrid(context,chartArea.width*0.9,chartArea.height/2,{color:'lightgray',lineWidth:2});
        context.fillStyle='blue';
        let x=10;

        for(let item of tempdata){
            drawBar(context,x,item);
            x+=30;
        }
    }
    function drawBar(ctx,x,data){
        ctx.fillRect(x,-data.temp,20,data.temp );
        ctx.save();

        ctx.fillStyle='black';
ctx.fillText(data.temp,x+5,-data.temp-10);

//ctx.rotate(+Math.PI/2);
/* ctx.fillText(data.day,20,-x-5);
        ctx.restore(); */
       /*  ctx.fillText('day'+data.day,x+5,20);
        ctx.restore(); */
        ctx.save();
        ctx.rotate(-Math.PI/2);
        const text='day '+data.day;
        const pos=Math.ceil(ctx.measureText(text).width+10);
        console.log(pos);
    ctx.fillText(text,-pos,x+15);
    ctx.restore();
    ctx.restore();
    
    }

    // for example the options could be {color:'red',lineWidth:3}
    function drawGrid(ctx,width,height,options){
        ctx.save();
ctx.strokeStyle=options.color;
ctx.lineWidth=options.lineWidth;
ctx.beginPath();
ctx.moveTo(0,options.lineWidth);
ctx.lineTo(0,-height);//this is y-axis
ctx.moveTo(0,options.lineWidth);
ctx.lineTo(width-options.lineWidth,options.lineWidth);
ctx.stroke();
ctx.beginPath();
for(let y=10; y<=height;y+=10){
ctx.moveTo(0,options.lineWidth-y);
ctx.lineTo(width - options.lineWidth,options.lineWidth-y);
ctx.stroke();
        ctx.restore();
    }
    }
    
})();