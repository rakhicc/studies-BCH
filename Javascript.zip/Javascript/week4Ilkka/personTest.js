'use strict';
const person=require('./person.json');
console.log(person);