const getFooterElement = () => {
  
}
// Sample usage - do not modify
console.log(getFooterElement());
