//Run the code and see that we are able to call the instance method
//getFullName on the instance user of the class User.

class User {
    constructor(firstName, lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    getFullName() {
        return "full name here";
    }
}

// Class usage
let user = new User("Sam", "Doe");
console.log(user.getFullName());
