'use strict';
const a=[1,2,3,4];
console.log(a);
console.log(Array(a.length));
console.log(Array(a.length).fill('?'));
console.log(Array(a.length).fill('?').join());
console.log(`values(${Array(a.length).fill('?').join(', ')})`);