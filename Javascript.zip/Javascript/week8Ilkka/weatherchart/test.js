'use strict';

(function(){
const texts=['abc','dfghijkl','qwerty','sdfrtgyuiopasdf'];
document.addEventListener('DOMContentLoaded',init);

function init(){
    const drawingArea=document.getElementById("drawingArea");
    const ctx=drawingArea.getContext('2d');
    ctx.translate(200,200);
    ctx.font='20pt Serif';
    ctx.fillText('test',0,0);
    let inc=0;
    for(let text of texts){
        ctx.save();
        ctx.rotate(-Math.PI/2);
        let pos=Math.ceil(ctx.measureText(text).width);
        ctx.fillText(text,-pos,inc+=30);
        ctx.restore();
    }
}



})();