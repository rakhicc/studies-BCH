//function sum
function sum(x,y) {
    console.log('hello sum');
    return x+y;
    
}
console.log(sum(3,5));
//function multiplication
function multiply(x,y) {
    console.log('hello multiply');
    return x*y;
    
}
console.log(multiply(3,5));

//function getCharCount of a string
function getCharCount(x) {
    console.log('hello getCharCount');
    return x.length;
    
}
console.log(getCharCount('language'));

'use strict';

/**
Complete the function shoutMyName such that it returns the name parameter
it receives all in upper case.

Tests:returns a string
makes string uppercase

 * @param {string} name
 */
function shoutMyName(name) {
    console.log('hello shoutMyName');
    return name.toUpperCase();
 
}

// Sample usage - do not modify
console.log(shoutMyName("Sam")); // "SAM"
console.log(shoutMyName("Charley")); // "CHARLEY"
console.log(shoutMyName("alex")); // "ALEX"

/**
Complete the function lowerName such that it returns
the name parameter it receives all in lower case.

Tests: returns a string
makes string lowercase

 * @param {string} name
 */
function lowerName(name) {
    console.log('hello lowerName');
    return name.toLowerCase();
}

// Sample usage - do not modify
console.log(lowerName("Sam")); // "sam"
console.log(lowerName("ALEX")); // "alex"

/**
Complete the function getFirstCharacter such that it returns
the first character of the name parameter it receives.

Tests: returns a string
returns first character

 * @param {string} name
 */
function getFirstCharacter(name) {
    console.log('hello getFirstCharacter');
    return name[0];
}

// Sample usage - do not modify
console.log(getFirstCharacter("Amsterdam")); // "A"
console.log(getFirstCharacter("Japan")); // "J"
/**
Complete the function getLastCharacter such that it returns
the last character of the name parameter it receives.

Tests:
returns a string
returns last character


 * @param {string} name
 */
function getLastCharacter(name) {
    console.log('hello getLastCharacter');
    return name[name.length-1]; 
}

// Sample usage - do not modify
console.log(getLastCharacter("Sam")); // "m"
console.log(getLastCharacter("Alex")); // "x"
console.log(getLastCharacter("Charley")); // "y"
/**
Complete the function skipFirstCharacter such that it returns all the characters except
the first one from the text parameter it receives.

Test:
returns a string
skips the first character

 * @param {string} text
 */
function skipFirstCharacter(text) {
    console.log('hello skipFirstCharacter');
    return text.substring(1); 
}

// Sample usage - do not modify
console.log(skipFirstCharacter("Xcode")); // "code"
console.log(skipFirstCharacter("Hello")); // "ello"
/**
Complete the function concatInitials such that it returns the firstNameInitial followed by
the lastNameInitial.

Tests:
returns a string
concats initials


 * @param {string} firstNameInitial
 * @param {string} lastNameInitial
 */
function concatInitials(firstNameInitial, lastNameInitial) {
    console.log('hello concatInitials');
    return firstNameInitial+lastNameInitial; 
}

// Sample usage - do not modify
console.log(concatInitials("J", "D")); // "JD"
console.log(concatInitials("S", "B")); // "SB"

//Complete the function getDescription such that it returns the first 10 characters of the text parameter it receives followed by an ellipsis.
//An ellipsis is the dot character written 3 times: ...
//Note: for this challenge, the ... should always be there, even if the text was shorter than 10 characters.

//Tests:
//returns a string
//returns first 10 chars followed by ellipsis


 //* @param {string} text
 //*/
function getDescription(text) {
    console.log('getDescription'); 
    
    if (text.length < 10) {
        return text.substring(0)+'...'
    } else {
        return text.substring(0,10)+'...';
        
    }

}
console.log(getDescription('languagejava')); 
console.log(getDescription('language'));

/**
Complete the function sayHello such that it interpolates the variable
tempname into a string "Hello name".

Test: returns a string
returns correct message


 * @param {string} name
 */
function sayHello(name) {
    console.log("interpolation")
    return `Hello ${name}` ;

}

// Sample usage - do not modify
console.log(sayHello("Alex")); // "Hello Alex"
console.log(sayHello("Sam")); // "Hello Sam"
/**
Complete the function getFullName such that it returns the full name
of the person using interpolation.
Tests
returns a string
returns full name

 * @param {string} firstName
 * @param {string} lastName
 */
function getFullName(firstName, lastName) {
 return `${firstName} ${lastName}`;
}

// Sample usage - do not modify
console.log(getFullName("Sam", "Doe")); // "Sam Doe"
console.log(getFullName("Alex", "Blue")); // "Alex Blue"
function getMultilineString() {
    return `I am learning JavaScript
and I found it to be
quite fun!`;
}

// Sample usage - do not modify
console.log(getMultilineString());
function capitalize(text) {
    let a= text;
    const b= a[0].toUpperCase()+a.substring(1).toLowerCase();
    return b;
}

console.log(capitalize('sam'));
console.log(capitalize('ANDREW'));

function convertnumbertostring(number) {
    const x= number.toString();
    return x;
}

console.log(convertnumbertostring(11));

function getNextAge(number) {
    const x=number+=1;
    return x;
}

console.log(getNextAge(11));

    let count=0;
    count=count+=1;
   console.log(count);

   const ageLimit =18;
   console.log(ageLimit);


function convertstringtonumber(text){
    return Number.parseInt(text);
}

console.log(convertstringtonumber('123abcder',10));

let answer=42;
console.log(answer.toString());