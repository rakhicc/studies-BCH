'use strict';
console.log(process.argv);
 const [,,...tail]=process.argv;
 //console.log(tail);
 const [, , createStatementFile,...rest]=process.argv;
 /* if(createStatementFile){
 console.log('file',createStatementFile)
} */
 //console.log(rest);
 if(process.argv.length>2){
     //console.log(process.argv[2]);
 }
