# consoletest.js - Notes

Program will read symbolname from console

when the program is started, you give symbolname after node and filename

```shell
> node consoletest rocket
```

or
```shell
> node consoletest smileyFace
```

## consoletest.js
```js
'use strict';

const [,,symbolname]=process.argv;

const symbols = { 
    smileyFace: String.fromCodePoint(0x1F642),
    rocket: String.fromCodePoint(0x1F680),
    flowers: String.fromCodePoint(0x1F490)
};

console.log(`${symbolname} as symbol ${symbols[symbolname]}`);
```
### steps

#### step 1
```js
const [,,symbolname]=process.argv;
```

Here we assign the name of the symbol that comes from the commandline to constant `symbolname`. We omit the two first arguments because we don't need them ( the two commas at the beginning)

#### step 2
```js
const symbols = { 
    smileyFace: String.fromCodePoint(0x1F642),
    rocket: String.fromCodePoint(0x1F680),
    flowers: String.fromCodePoint(0x1F490)
};
```

This is an object which has our unicode symbols as key-value pairs.
We have 3 symbols.

#### step 3

we can access the symbol with objcts array-notation.
```js
symbols[symbolname]
```

We print the symbol to the console with 
```js
console.log(`${symbolname} as symbol ${symbols[symbolname]}`);
```
#### output 1
```shell
> node consoletest rocket
rocket as symbol 🚀
```

#### output 2
```shell
> node consoletest smileyFace
smileyFace as symbol 🙂
```