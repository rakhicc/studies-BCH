'use strict';
const [,,...operatorArray] = process.argv;
console.log('aray is',operatorArray)
let result;
if (operatorArray[1] === '+') {
result =Number(operatorArray[0])+Number(operatorArray[2]);
} else if (operatorArray[1] === '-') {
    result =Number(operatorArray[0])-Number(operatorArray[2]);
} else if (operatorArray[1] === 'x') {
    result =Number(operatorArray[0])*Number(operatorArray[2]);
} else if (operatorArray[1] === '/') {
    result =Number(operatorArray[0])/Number(operatorArray[2]);
} else {
    console.log('No condition met');
}

console.log(`${operatorArray[0]}  ${operatorArray[1]} ${operatorArray[2]}= ${result}`);