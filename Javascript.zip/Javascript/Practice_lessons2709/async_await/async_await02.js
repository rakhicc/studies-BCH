'use strict';

/*
You're provided with an async function getMinimumVotingAge. Do not change it.
Instead, you should write the sample usage this time.
Use the getMinimumVotingAge function and then console.log the value that it returns.
*/

// do NOT modify the function
const getMinimumVotingAge = async () => {
    return 18;
}

// Sample usage. TODO: write it yourself
 getMinimumVotingAge().then(value => {
    console.log(value);
});
