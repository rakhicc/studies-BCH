const getNumberOfLinks = () => {
const nodeListoflinks = document.querySelectorAll("a");
return nodeListoflinks.length;
}

// Sample usage - do not modify
console.log(getNumberOfLinks()); // 5
