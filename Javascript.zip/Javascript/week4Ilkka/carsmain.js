'use strict';
const {getwithmodel,getAllModels,getcar}=require('./carssample');
console.log(getwithmodel('abc2'));
console.log(`\nAll available models:\n\t${getAllModels().join('\n\t')}`);
console.log(getcar('model','abc'));
console.log(getcar('licence','x'));
