'use strict';

const [,,numberA,numberB]=process.argv;

console.log(`sum = ${+numberA + +numberB}`);
console.log(`sum is ${Number(numberA)+Number(numberB)}`);