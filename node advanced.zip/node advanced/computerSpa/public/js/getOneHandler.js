'use strict';



(function(){
 let resultarea;
 let inputfield;

 document.addEventListener('DOMContentLoaded',init);
 function init(){
     resultarea=document.getElementById('resultarea');
     inputfield=document.getElementById('id');
     document.getElementById('submit').addEventListener('click',send);

 }

async function send(){
    clearMessagearea();
    resultarea.innerHTML='';
    const id=inputfield.value;
    console.log(id);
    try{
const options={
    method:'POST',
    body:JSON.stringify({id}),
    headers:{
        'Content-Type':'application/json'
    }

};
const data=await fetch('/getOne',options);
const resultJson=await data.json();
updatePage(resultJson);
    }catch(error){
    updateMessagearea(error.message,'error');
}
}
function updatePage(result){
    if(result){
        if(result.message){
            updateMessagearea(result.message,result.type);
        } else {
            updateComputer(result);
        }
    }
}
function updateComputer(computer){
    resultarea.innerHTML=`
<p><span class="legend">Id:</span>${computer.id}</p>
<p><span class="legend">Name:</span>${computer.name}</p>
<p><span class="legend">Type:</span>${computer.type}</p>
<p><span class="legend">Processor:</span>${computer.processor}</p>
<p><span class="legend">Amount:</span>${computer.amount}</p>
`;
}
})();