export default{
    "host":"localhost",
    "port":3306,
    "user":"HR",
    "password":"password",
    "database":"npsdb"
}