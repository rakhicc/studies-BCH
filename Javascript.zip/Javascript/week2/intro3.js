'use strict';
const binary=0b11101;
console.log(binary);
// const octa=020; //not working in strict mode
// console.log(octa);
const octanumber=0o20
console.log(octanumber);
const eigth=0o10;
console.log(eigth);
const hex=0xFF;
console.log(hex);
const fftest=0b11111111;
console.log(fftest);

console.log(binary.toString(16).toUpperCase());
console.log(binary.toString(8));
console.log(binary.toString(2));
console.log(binary.toString(2).padStart(8,'0'));

console.log('\u2663');
console.log(String.fromCodePoint(0x1F680,0x2663));
const smileyFace=String.fromCodePoint(0x1F642);
console.log(smileyFace);

const symbols={ //an object
    smileyFace: String.fromCodePoint(0x1F642),
    rocket: String.fromCodePoint(0x1F680)
};


console.log(symbols.rocket);
console.log(symbols.smileyFace);

console.log(symbols['rocket']);


symbols.flowers=String.fromCodePoint(0x1F490);

let symb='flowers';

console.log('rocket:',symbols[symb]); //not good: hard coded label rocket
console.log(`${symb}= ${symbols[symb]}`);

if(symb==='rocket'){
    console.log(`rocket= ${symbols.rocket}`);
} 
else if(symb==='smileyFace'){
    console.log(`smileyFace= ${symbols.smileyFace}`);
}
else {
    console.log('what?')
}

console.log(Object.keys(symbols));
