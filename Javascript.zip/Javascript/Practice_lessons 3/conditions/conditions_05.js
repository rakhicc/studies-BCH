'use strict';

/**
What number's bigger?
Write a function named greaterNum that:
takes 2 arguments, both numbers.
returns whichever number is the greater (higher) number.
Call that function 2 times with different number pairs, and log the output to make sure it works
(e.g. "The greater number of 5 and 10 is 10.").
**/

function greaterNum(number1, number2) {
    if (number1 > number2) {
        return `The greater number of ${number1} and ${number2} is ${number1}`;
    } else if (number2 > number1){
        return `The greater number of ${number1} and ${number2} is ${number2}`;
    }
    }


// Sample usage - do not modify
console.log(greaterNum(5, 10));
console.log(greaterNum(25, 20));
