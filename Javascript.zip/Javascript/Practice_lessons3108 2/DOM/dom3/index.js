const getArticleTitle = () => {

}

// Sample usage - do not modify
console.log(getArticleTitle()); // "First human lands on Mars!"
