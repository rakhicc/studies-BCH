'use strict';
(function(){
document.addEventListener('DOMContentLoaded',init);
function init(){
    const drawingArea=document.getElementById("drawingArea");
    const context=drawingArea.getContext('2d');
    context.strokeStyle='red';
    context.lineWidth=5;
    context.fillStyle='orange';
    //           x, y,radius,beginangle in radians,angletobedrawn in radinas
    context.arc(150,100,50,0,2*Math.PI);
    context.closePath();
    context.fill();
    context.stroke();

    context.lineWidth=1;
    context.strokeStyle='black';
    context.fillStyle='rgba(45,45,200,0.5)';
    context.beginPath();
    context.arc(100,100,50,0,2*Math.PI);
    context.closePath();
    context.fill();
    context.stroke();

    context.beginPath();
    context.lineWidth=5;
    context.moveTo(200,200);
    context.lineTo(200,250);
    context.lineTo(300,250);
    //context.closePath();
    context.lineTo(200,200);
    context.stroke();
    context.fill();

    let diamond=new Image();
    diamond.src='Frame.svg';
    diamond.onload=drawDiamond;
    function drawDiamond(){
        context.drawImage(diamond,10,200);
        context.drawImage(diamond,300,300,40,40);
        for(let x=0;x<400;x+=40){
            context.drawImage(diamond,x,0,40,40);
        }
    }



}



})();