/* give the card suite as text from inputline (spade,clubs, hearts, diamond)

program prints out the suite symbol

'\u2660', \u2663', \u2665', \u2666'

output hint:
`${suite}` */

'use strict;'

if(process.argv.length ===3) {
const [,,suite='?'] = process.argv;// we can give default value to argv
console.log(suite);
//console.log('\u2663');
 let symbol;
if(suite === 'clubs'){
symbol = '\u2663';
} 
else if (suite === 'hearts'){
    symbol = '\u2665'; 
}else if (suite === 'diamond'){
    symbol = '\u2666'; 
}else if (suite === 'spade'){
    symbol = '\u2660'; 
} 

else {
    console.log('no conditions met');

} 
console.log(`symbol of suite ${suite} is ${symbol}`);
}else {
    console.log(`${'#'.repeat(40)} parameter is not present ${'#'.repeat(40)}`);
    
}


