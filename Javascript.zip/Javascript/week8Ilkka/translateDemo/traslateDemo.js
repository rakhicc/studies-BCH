'use strict';
(function(){
document.addEventListener('DOMContentLoaded',init);
function init(){
    const drawingArea=document.getElementById("drawingArea");
    const context=drawingArea.getContext('2d');
   /*  context.translate(200,200);
    context.moveTo(0,0);
    context.lineTo(100,0);
    context.moveTo(0,0);
    context.lineTo(0,100);
    context.stroke();
    context.fillRect(0,0,20,20); */
    for (let x=0;x<400;x+=45){
        drawBox(context,x,30);
        drawTriangle(context,x,200);
    }
    context.scale(1,-1);
    
    drawTriangle(context,100,-300,80,'orange');
context.scale(1,-1);
    context.fillText('adada',100,100);
}
function drawBox(ctx,x,y,size=40,color='red'){
    ctx.save();
    ctx.translate(x,y);
    ctx.fillStyle=color;
    ctx.fillRect(0,0,size,size);
    ctx.restore();
}
function drawTriangle(ctx,x,y,size=40,color='green'){
    const midpoint=Math.floor(size/2);
    ctx.save();
    ctx.translate(x,y);
    ctx.beginPath();
    ctx.moveTo(midpoint,0);
    ctx.lineTo(size,size);
    ctx.lineTo(0,size);
    ctx.closePath();
    ctx.fillStyle=color;
    ctx.fill()
    ctx.restore();
}
})();