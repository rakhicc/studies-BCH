# turtle API

### `npm install` to install dependencies

### `node createdatabase` to run database queries

### `node indexREST` to up the server

### `node indexSPA` to access single page application
