'use strict';

const personalLibrary = require('./books.json');

function getBooksOfPerson(firstname, lastname){
    for(let person of personalLibrary){
        if(person.firstname===firstname && person.lastname===lastname){
            return person.books;
        }
    }
    return [];
}

/* function getTheNamesOfBooks(firstname, lastname){
    const found=[];
    for(let person of personalLibrary) {
        if(person.firstname===firstname && person.lastname===lastname){
            for(let book of person.books){
                found.push(book.name);
            }
        }
    }
    return found;
} */

function getTheNamesOfBooks(firstname, lastname){
    const found=[];
    for(let person of personalLibrary) {
        if(person.firstname===firstname && person.lastname===lastname){
            return person.books.map(book=>book.name);
        }
    }
    return [];
}

function gettotalprice(firstname, lastname){
    let price=0;
    for(let person of personalLibrary){
        if(person.firstname===firstname && person.lastname===lastname){
            for(let book of person.books){
                price=price+book.price;}
            }
        }
        return price;

}

function getownerOfBooks(name){
    const owners=[];
    for(let person of personalLibrary){
        for(let book of person.books){
            if(book.name ===name){
                owners.push(`${person.firstname} ${person.lastname}`);
            }
        }
    }
    return owners;
}

/* function getAllbooksthatIncludes(substring){
    const personArray=[];
    for(let person of personalLibrary){
        for(let book of person.books){
            if(book.name.includes(substring)){
                const personobject={
                    firstname:person.firstname,
                    lastname:person.lastname,
                    Book:{name:book.name,pages:book.pages,price:book.price}
                };
                personArray.push(JSON.stringify(personobject));

}
        }
    }
        return personArray;
    }
 */

    function getAllbooksthatIncludes(substring){
        const personArray=[];
        for(let person of personalLibrary){
            for(let book of person.books){
                if(book.name.includes(substring)){
                    personArray.push(
                        {firstname:person.firstname,
                        lastname:person.lastname,
                        Book:book});
    
    }
            }
        }
            return personArray;
        }
    
module.exports={
    getBooksOfPerson,
    getTheNamesOfBooks,
    gettotalprice,
    getownerOfBooks,
    getAllbooksthatIncludes
};


