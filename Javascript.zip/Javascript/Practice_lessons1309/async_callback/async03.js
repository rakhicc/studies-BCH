'use strict';

/**
Run the code by adding a comment at the end of the file (code changes will re-run the code) and take a look at the output.
Your code is running top to bottom, however, some code might be scheduled into the future.
Feel free to play around with the code and see how that affects the result...*/

console.log("A");

setTimeout(() => {
    console.log("B");
}, 2000);

console.log("C");
