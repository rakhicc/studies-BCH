function maskify(string){
    let argument=string;
let substring=string.substring(0,string.length-4);
let subtr='';
for(let i=0;i<substring.length;i++){
    subtr=subtr+'#';
}
console.log('subtr',subtr)
let result=argument.replace(substring,subtr);
/* 
// santhish's solution
let regex=/.(?=.{4})/g;

let result = argument.replace(regex, subtr); */
return result;
}

console.log(maskify("Skippy"));
console.log(maskify("Nananananananananananananananana Batman!"));