const getAllLinks = () => {
return document.querySelectorAll("a");
}

// Sample usage - do not modify
console.log(getAllLinks());
