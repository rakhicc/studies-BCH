'use strict';
for(let i=0;i<10;i++){
//console.log(Math.random());
//console.log(Math.random()*4);
//console.log(Math.floor(Math.random()*4));
console.log(Math.ceil(Math.random()*13));
}

const randomInt=() =>{
    return console.log('method fn '+Math.floor(Math.random()*4));
}
randomInt();
// while loop
let k=0;
while(k<10){
    console.log(k);
    k++;
}
function square(size,symbol='#'){
let result ='';
for(let i=0;i<size;i++){
    for(let j=0;j<size;j++){
    result = result+symbol;
    }  
    result+='\n'; 
}
//console.log(result);
return result;
}
console.log('result is '+'\n'+square(10,'*'));