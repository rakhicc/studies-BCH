const item=document.getElementById("item");
const form=document.querySelector("form");
const ul=document.querySelector("ul");
const button=document.querySelector("button");
let itemsArray=localStorage.getItem('items') ? JSON.parse(localStorage.getItem('items')):[];
localStorage.setItem('items',JSON.stringify(itemsArray));
const data = JSON.parse(localStorage.getItem('items'));
const limaker=(text)=>{
    const li=document.createElement('li');
    li.textContent=text;
    ul.appendChild(li);
}
    form.addEventListener('submit',function(e){
        e.preventDefault();
        itemsArray.push(item.value);
localStorage.setItem('items',JSON.stringify(itemsArray));
  limaker(item.value) ;
  item.value='' ;
});
data.forEach(item => {
   limaker(item); 
});
button.addEventListener('click',function(){
    localStorage.clear()
    while (ul.firstChild){
        ul.removeChild(ul.firstChild);
    }
    itemsArray=[];
});
