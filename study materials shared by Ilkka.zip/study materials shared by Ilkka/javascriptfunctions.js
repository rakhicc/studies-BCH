function sum(x,y) {
    return x+y;
    console.log('hello world');
}