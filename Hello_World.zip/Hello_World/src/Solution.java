import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;



class Result {

    /*
     * Complete the 'encryptionValidity' function below.
     *
     * The function is expected to return an INTEGER_ARRAY.
     * The function accepts following parameters:
     *  1. INTEGER instructionCount
     *  2. INTEGER validityPeriod
     *  3. INTEGER_ARRAY keys
     */

    public static List<Integer> encryptionValidity(int instructionCount, int validityPeriod, List<Integer> keys) {
    // Write your code here
    	List<Integer> result = Arrays.asList(0, 0);
    	Map<Integer, Integer> degreeOfDivisibilityCache = new HashMap<>();

    	for (int i: keys) {
    	    Integer degreeOfDivisibility = degreeOfDivisibilityCache.getOrDefault(i, -1);

    	    if (degreeOfDivisibility == -1) {
    	        int count = 0;
    	        for (int j : keys) {
    	            if (j > 0 && i % j == 0) {
    	                count++;
    	            }
    	        }
    	        degreeOfDivisibilityCache.put(i, count);
    	    }
    	}

    	int maxDegreeOfDivisibility = degreeOfDivisibilityCache.values().stream()
    	        .max(Comparator.comparingInt(Integer::intValue)).orElse(0);
    	int s = maxDegreeOfDivisibility * 100000;
    	result.set(1, s);

    	BigInteger ic = BigInteger.valueOf(instructionCount);
    	BigInteger a = ic.multiply(BigInteger.valueOf(validityPeriod));
    	if (a.compareTo(BigInteger.valueOf(s)) > 0) {
    	    result.set(0, 1);
    	}
    	return result;
    }

}

public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        //BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

        int instructionCount = 1000;
        		//Integer.parseInt(bufferedReader.readLine().trim());

        int validityPeriod = 10000;
        		//Integer.parseInt(bufferedReader.readLine().trim());

        int keysCount = Integer.parseInt(bufferedReader.readLine().trim());

        List<Integer> keys = new ArrayList<>();
        keys.add(2);
        keys.add(4);
        keys.add(8);
        keys.add(2);
        System.out.println(keys);
        		//IntStream.range(0, keysCount).mapToObj(i -> {
            //try {
                //return bufferedReader.readLine().replaceAll("\\s+$", "");
            //} catch (IOException ex) {
                //throw new RuntimeException(ex);
            //}
        //})
           // .map(String::trim)
            //.map(Integer::parseInt)
           // .collect(toList());

        List<Integer> result = Result.encryptionValidity(instructionCount, validityPeriod, keys);
System.out.println("result is"+result);
       // bufferedWriter.write(
            //result.stream()
                //.map(Object::toString)
                //.collect(joining("\n"))
            //+ "\n"
        //);

        bufferedReader.close();
        //bufferedWriter.close();
    }
}