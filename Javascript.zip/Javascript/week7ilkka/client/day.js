'use strict';
(function(){
    let result;
    let jsondata;
    let button;
    let weatherdata;
    document.addEventListener('DOMContentLoaded',init);
    async function init(){
        try{
            console.log("init");
const data = await fetch('http://localhost:3000',{mode:'cors'});

 jsondata=await data.json();
 button=document.getElementById("submitbutton");
 button.addEventListener('click',update); 
 
 
 
 
}
catch(error){
    console.log(error.message);
}
}

  function update(){
    const inputvalue=document.getElementById("day");
    const ul=document.getElementById("ul");
    console.log(inputvalue.value);
    for(let item of jsondata){
        if (item.day===(+inputvalue.value)){
const p=document.createElement("p");
p.textContent=`temperature : ${item.temp} °C`;
ul.insertAdjacentHTML('beforeend', `<p>temperature : ${item.temp} °C</p>`);
const p1=document.createElement("p");
p1.textContent=`rain : ${item.rain} `;
ul.insertAdjacentHTML('beforeend', `<p>rain : ${item.rain} </p>`);
const p2=document.createElement("p");
p2.textContent=`temperature : ${item.cloudSymbol} `;
ul.insertAdjacentHTML('beforeend', `<p>symbol : ${item.cloudSymbol}</p>`);
        }
    }
  }  
function returnRowsofdata(item){
    const tr=document.createElement("tr");
    let td=document.createElement("td");
    td.textContent=item.day;
    tr.appendChild(td);
    td=document.createElement("td");
    td.textContent=item.temp;
    tr.appendChild(td);
    td=document.createElement("td");
    td.textContent=item.rain;
    tr.appendChild(td);
    td=document.createElement("td");
    td.textContent=item.cloud;
    tr.appendChild(td);
    td=document.createElement("td");
    td.textContent=item.cloudSymbol;
    if(item.cloud===0){
     td.classList.add("sunny");   
    }
    if(item.cloud===3){
        td.classList.add("umbrella");   
       }
    tr.appendChild(td);
    return tr;
    }
//the function above can be shortified as below:
    /* function createRow(item){
        const tr=document.createElement("tr");
        for (let value of Object.values(item)){
            const td=document.createElement("td");
            td.textContent=value;
            tr.appendChild(td);
        }
        return tr;
    } */
    function createRow(item){
        const tr=document.createElement("tr");
        for (let [key,value] of Object.entries(item)){
            const td=document.createElement("td");
            td.textContent=value;
            if(key==='cloudSymbol'){
                if(item.cloud===0) td.classList.add('sunny');
                if(item.cloud===3) td.classList.add('umbrella');
            }
            tr.appendChild(td);
        }
        return tr;
    }
}
)();