'use strict';
const library=require('./books.json');
function getbooksofaperson(firstname,lastname){
    for(let person of library){
        let booksArray=[];   if(person.firstname===firstname && person.lastname===lastname){
            return person.books;
        }
        return [];
    }
}
//console.log(getbooksofaperson('rakhi','chandran'));

function getnamesofbooks(firstname,lastname){
    const found =[];
    for(let person of library){
        
        if(person.firstname===firstname && person.lastname===lastname){
            for(let book of person.books){
                found.push(book.name);
            }
        }
        
    }
    return found;
}
module.exports={getbooksofaperson,getnamesofbooks};
