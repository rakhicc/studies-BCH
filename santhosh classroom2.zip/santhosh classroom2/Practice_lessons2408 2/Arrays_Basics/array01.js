'use strict';

/**
Complete the function getEmptyArray such that it returns an empty array.

/**
 * @param {empty}
 */

 function getEmptyArray() {

 }

 // Sample usage - do not modify
 console.log(getEmptyArray());
