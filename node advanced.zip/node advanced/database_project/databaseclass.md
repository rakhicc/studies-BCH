# database class

This database class is a general purpose class for creating and using mariadb/Mysql queries.
The constructor takes all necessary information needed to open a database connection as a parameter object. This layer is used between the database engine and our application.
The constructor takes one parameter. Example

```js
{
host:'localhost',
port:3306,
user:'zeke',
password:'secret',
database:'employeedb',
allowPublicKeyretrieval:true
}
```

##usage

```js
const db = new Database(options);
```

The **doQuery(sql,parameters)** method has two parameters:
`sql`:is a sql statement as string
`parameters`:an array of query parameters to be used in place of the question marks `?`in the sql statement. parameters may also be omitted if the sql statment has no placeholder `?`in it.

###usage

#### No parameters needed

```js
const result = await db.doQuery("select * from employee");
```

#### Query criteria is employeeid is 1

```js
const result = await db.doQuery("select * from employee=?", [1]);
```

Return value of select query with employee Id 1:

```js
{
    queryResult:[
        {
            employeeId:1,
            firstname:'Matt',
            lastname:'River',
            department:'ict',
            salary:5000
        }
    ],
    resultset:true
}
```

#### insert, update,delete etc

##### insert

````js
const result=await db.doQuery('insert into employee values(?,?,?,?,?),[6,'Petra','Bond','admin','9000]);
Return value is an object
```js
{
    queryResult:{rowsChanged:1,insertId:0,status:0},
    resultSet:false
}
````

```

```
