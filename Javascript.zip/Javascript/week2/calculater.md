# commandline calculator

Operations +, -, x, / (refered as op)

program takes three value as input

numberA op numberB
   1     +    4

1 + 4
3 x 5

You need if statement to decide which operation to perform

output result for example: 1 + 4 = 5

no error checking in this version needed. Program just fails miserably.
