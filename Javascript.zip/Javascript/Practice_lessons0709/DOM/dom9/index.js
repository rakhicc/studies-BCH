const logLinksTexts = () => {
const nodelistofLinks = document.querySelectorAll("a");
nodelistofLinks.forEach(nodelistofLink => console.log(nodelistofLink.textContent));
}

// Sample usage - do not modify
logLinksTexts();
