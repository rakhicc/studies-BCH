'use strict';

const cars = require('./cars.json');

console.log(cars);
console.log(cars[0].model);
console.log(`${cars[1].model}: ${cars[1].licence}`);
console.log(cars[3]);
console.log(cars[cars.length-1]);

for(let car of cars){
    console.log(car.model);
}

//print licences of Fast GT cars
for(let car of cars){
    // if(car.model==='Fast GT'){
    //     console.log(car.licence);
    // }
    if (car.model.toLowerCase() === 'fast gt') {
        console.log(car.licence);
    }
}

const models=[];
for(let car of cars){
    if(!models.includes(car.model)){
        models.push(car.model);
    }
}
console.log(`Available car models: ${models.join(', ')}`);

//print the model of the car with licence of ABC-1
for(let car of cars){
    if(car.licence==='ABC-1'){
        console.log(car.model);
    }
}