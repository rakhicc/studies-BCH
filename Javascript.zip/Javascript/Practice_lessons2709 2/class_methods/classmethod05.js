/*
Implement the following instance methods for the class Recipe:

isLowCaloric that returns true when the calories of the recipe are 400 or below and false otherwise.
isHighCaloric that returns true when the calories of the recipe are 600 or above and false otherwise.
*/
class Recipe {
   constructor(name, calories) {
       this.name = name;
       this.calories = calories;
   }
   isLowCaloric( calories){
       if(calories<=400){
           return true;
       }
       return false;
   }
   isHighCaloric(calories){
    if(calories>=600){
        return true;
    }
    return false;
}
   //TODO
   
}

// class usage
let pasta = new Recipe("Pasta", 700);
// TODO: use the methods as you define them
console.log(pasta.isLowCaloric(700));
console.log(pasta.isHighCaloric(700));
let salad = new Recipe("Salad", 350);
console.log(salad.isLowCaloric(350));
console.log(salad.isHighCaloric(350));
// TODO: use the methods as you define them
