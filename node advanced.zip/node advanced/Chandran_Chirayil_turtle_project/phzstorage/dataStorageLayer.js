'use strict';
const Database=require('./database');
const options=require('./databaseOptions.json');

const {CODES,TYPE,MESSAGES}=require('./phz_statuscodes');
const sql=require('./phz_sqlqueries.json');
const {toArrayInsert}=require('./parameters')

const insertSql=sql.insert.join(' ');

const PRIMARY_KEY=sql.primaryKey;

console.log(insertSql);
console.log(PRIMARY_KEY);

module.exports=class Datastorage{
    constructor(){
        this.db=new Database(options);
    }
    get CODES(){
        return CODES;
    }
 
    insert(resource){
        return new Promise(async (resolve,reject)=>{
            try{
await this.db.doQuery(insertSql,toArrayInsert(resource));
resolve (MESSAGES.INSERT_OK(PRIMARY_KEY,resource[PRIMARY_KEY]));
            }catch(error){
                console.log(error);
                reject(MESSAGES.NOT_INSERTED());
            }
        })
    }//end of insert

}


